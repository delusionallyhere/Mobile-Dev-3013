package com.example.colorpicker

import android.app.Activity.RESULT_OK
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import android.widget.Toolbar
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.color_picker.*
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException

var colorArray = arrayListOf<String>()

class MainActivity : AppCompatActivity(), SeekBar.OnSeekBarChangeListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        setSupportActionBar(findViewById(R.id.toolbar))

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setLogo(R.drawable.app_icon)
        supportActionBar?.setDisplayUseLogoEnabled(true)

        redSeekBar.max = 255
        greenSeekBar.max = 255
        blueSeekBar.max = 255

        redSeekBar.setOnSeekBarChangeListener(this)
        greenSeekBar.setOnSeekBarChangeListener(this)
        blueSeekBar.setOnSeekBarChangeListener(this)

        redNumberView.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                redSeekBar.progress = redNumberView.text.toString().toInt()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        greenNumberView.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                greenSeekBar.progress = greenNumberView.text.toString().toInt()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        blueNumberView.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                blueSeekBar.progress = blueNumberView.text.toString().toInt()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
        when (seekBar) {
            redSeekBar -> redNumberView.text.toString().toInt(redSeekBar.progress)
            greenSeekBar -> greenNumberView.text.toString().toInt(greenSeekBar.progress)
            blueSeekBar -> blueNumberView.text.toString().toInt(blueSeekBar.progress)
        }

        val newColor: Int = Color.rgb(
            redNumberView.text.toString().toInt(),
            greenNumberView.text.toString().toInt(),
            blueNumberView.text.toString().toInt()
        )
        colorPreview.setBackgroundColor(newColor)
    }

    override fun onStartTrackingTouch(seekBar: SeekBar?) {   }
    override fun onStopTrackingTouch(seekBar: SeekBar?) {   }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val colorFileName = "colors.txt"
        val colorListFragment = supportFragmentManager.findFragmentById(R.id.colorListFrag) as ColorListFragment
        val colorData = findViewById<EditText>(R.id.colorEditText).text.toString()
        val id = item.itemId
        val file = File(filesDir.absolutePath + "/colors.txt")

        if (id == R.id.saveColor && !colorEditText.text.isBlank()) {
            val color = "${colorData.toLowerCase()} ${redNumberView.text} ${greenNumberView.text} ${blueNumberView.text}\n"
            try {
                if (file.exists()) {
                    println("EXISTS")
                    openFileOutput(colorFileName, Context.MODE_APPEND).use { it.write(color.toByteArray()) }
                }
                else {
                    openFileOutput(colorFileName, Context.MODE_PRIVATE).use { it.write(color.toByteArray()) }
                }
            } catch (e: FileNotFoundException) {
                e.printStackTrace()
            } catch (e: IOException) {
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            colorEditText.text.clear()
            colorListFragment.getSavedColors()
            colorListFragment.updateColors()
            return true
        }
        else if (id == R.id.loadColor) {
            try {
                colorListFragment.getSavedColors()
                colorListFragment.updateColors()
                Toast.makeText(this, "Loaded", Toast.LENGTH_SHORT).show()

            } catch (e: FileNotFoundException) {
                Toast.makeText(this, "No Existing Colors!", Toast.LENGTH_SHORT).show()
            }
            return true
        }
        else if (id == R.id.sendButton) {
            val info = intent.extras
            if (info != null) {
                    if(info.containsKey("Request Code")) {
                        println("Key Inside!")
                        var returnText = getColorString()
                        finish()
                    }
            }
        }


        else
            Toast.makeText(this, "No color name entered.", Toast.LENGTH_SHORT).show()
        return super.onOptionsItemSelected(item)
        }


    fun onColorListClick (view: View) {
        var tempColor = ((view.background as ColorDrawable).color)
        val red: Int = tempColor shr 16 and 0xFF
        val green: Int = tempColor shr 8 and 0xFF
        val blue: Int = tempColor shr 0 and 0xFF
        println("$red $green $blue")
        Toast.makeText(this, "Loaded", Toast.LENGTH_SHORT).show()
        redNumberView.text.toString().toInt(red)
        greenNumberView.text.toString().toInt(green)
        blueNumberView.text.toString().toInt(blue)
        redSeekBar.progress = red
        greenSeekBar.progress = green
        blueSeekBar.progress = blue
        colorPreview.setBackgroundColor(tempColor)
    }

    private fun getColorString(): String {
        var tempColor = ((colorPreview.background as ColorDrawable).color)
        val red: Int = tempColor shr 16 and 0xFF
        val green: Int = tempColor shr 8 and 0xFF
        val blue: Int = tempColor shr 0 and 0xFF
        return "$red $green $blue"
    }

    override fun finish() {
            val sendIntent = Intent().apply {
                    putExtra("colorText", getColorString())
                    type = "text/plain"
            }
            setResult(RESULT_OK, sendIntent)
            super.finish()
    }
}


